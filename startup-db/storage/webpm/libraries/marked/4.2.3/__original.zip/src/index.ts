export * from "marked";
/*



return async ({debug}) => {
    const CDN = window['@youwol/cdn-client']
    const FluxView = window['@youwol/flux-view']
    await CDN.install({modules:["marked#^4.2.3"]})

    return true
}

 */
