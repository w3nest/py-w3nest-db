import DefaultImport from 'codemirror'
export { setup as webpmSetup } from './auto-generated'
export * from 'codemirror'
export default DefaultImport
