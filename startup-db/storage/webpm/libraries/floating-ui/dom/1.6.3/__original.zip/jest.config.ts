import { Config } from 'jest'

const jestConfig: Config = {
    preset: '@youwol/jest-preset',
    modulePathIgnorePatterns: [],
}
export default jestConfig
