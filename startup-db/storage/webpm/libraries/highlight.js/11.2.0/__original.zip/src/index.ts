import DefaultImport from 'highlight.js'
export { setup as webpmSetup } from './auto-generated'
export * from 'highlight.js'
export default DefaultImport
