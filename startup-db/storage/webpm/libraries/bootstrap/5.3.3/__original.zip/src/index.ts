import DefaultImport from 'bootstrap'
export { setup as webpmSetup } from './auto-generated'
export * from 'bootstrap'
export default DefaultImport
