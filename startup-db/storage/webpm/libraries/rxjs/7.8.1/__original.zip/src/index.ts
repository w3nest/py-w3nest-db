export { setup as webpmSetup } from './auto-generated'
export * from 'rxjs'
export { default } from 'rxjs'

export * as ajax from 'rxjs/ajax'
export * as fetch from 'rxjs/fetch'
export * as operators from 'rxjs/operators'
export * as testing from 'rxjs/testing'
export * as webSocket from 'rxjs/webSocket'

// export * as a from 'rxjs/internals'
