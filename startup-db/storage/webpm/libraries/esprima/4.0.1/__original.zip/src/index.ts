import DefaultImport from "esprima"
export {setup as webpmSetup} from './auto-generated'
// It may be the case that one of the two following line is not needed
export * from "esprima"
export default DefaultImport

